import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class Sepatu {
  final String merek;
  final String model;
  final int ukuran;
  final double jarakTempuhKm;
  final int harga;
  final bool masihAktif;

  const Sepatu({
    required this.merek,
    required this.model,
    required this.ukuran,
    required this.jarakTempuhKm,
    required this.harga,
    required this.masihAktif,
  });

  String get hargaFormatted {
    return harga.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]}.',
    );
  }
}

const List<Sepatu> daftarSepatu = [
  Sepatu(
    merek: 'Asics',
    model: 'Gel-Nimbus 25',
    ukuran: 42,
    jarakTempuhKm: 320.5,
    harga: 2100000,
    masihAktif: true,
  ), 
  Sepatu(
    merek: 'Nike',
    model: 'Pegasus 40',
    ukuran: 41,
    jarakTempuhKm: 515.0,
    harga: 1800000,
    masihAktif: true,
  ),
  Sepatu(
    merek: 'Adidas',
    model: 'Adizero Boston',
    ukuran: 43,
    jarakTempuhKm: 610.2,
    harga: 1950000,
    masihAktif: false,
  ),
  Sepatu(
    merek: 'Hoka',
    model: 'Clifton 9',
    ukuran: 42,
    jarakTempuhKm: 150.0,
    harga: 2300000,
    masihAktif: true,
  ),
];

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Koleksi Sepatu Lari',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
        appBarTheme: const AppBarTheme(centerTitle: true),
      ),
      home: const HalamanUtama(),
    );
  }
}

class HalamanUtama extends StatelessWidget {
  const HalamanUtama({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Koleksi Sepatu Lari')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: daftarSepatu.length,
        itemBuilder: (context, index) {
          return KartuSepatu(sepatu: daftarSepatu[index]);
        },
      ),
    );
  }
}

class KartuSepatu extends StatelessWidget {
  final Sepatu sepatu;

  const KartuSepatu({super.key, required this.sepatu});

  @override
  Widget build(BuildContext context) {
    final skema = Theme.of(context).colorScheme;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: skema.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.directions_run,
                    color: skema.onPrimaryContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${sepatu.merek} ${sepatu.model}',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      Text('Ukuran ${sepatu.ukuran}'),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text('Jarak tempuh: ${sepatu.jarakTempuhKm} km'),
            Text('Harga: Rp ${sepatu.hargaFormatted}'),
            Text(
              sepatu.masihAktif
                  ? 'Status: masih dipakai'
                  : 'Status: sudah pensiun',
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${sepatu.model} dicatat sebagai favorit'),
                    ),
                  );
                },
                child: const Text('Tandai Favorit'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}